extends Node2D

var centro = Vector2(540, 540)

var radio1 = 290.0
var radio2 = 350.0
var radio3 = 420.0

var angulo1 = 0.0
var angulo2 = 0.0
var angulo3 = 0.0

var vel_planeta1 = 1.5
var vel_planeta2 = 1.0
var vel_planeta3 = 0.7

func _ready():
	$sol.position = centro
	
	$planeta1/Sprite2D.scale = Vector2(0.2, 0.2)
	$planeta2/Sprite2D.scale = Vector2(0.1, 0.1)
	$planeta3/Sprite2D.scale = Vector2(0.3, 0.3)
	$sol/Sprite2D.scale = Vector2(1, 1)


func _process(delta):
	angulo1 += vel_planeta1 * delta
	angulo2 += vel_planeta2 * delta
	angulo3 += vel_planeta3 * delta

	$planeta1.position = centro + Vector2(cos(angulo1), sin(angulo1)) * radio1
	$planeta2.position = centro + Vector2(cos(angulo2), sin(angulo2)) * radio2
	$planeta3.position = centro + Vector2(cos(angulo3), sin(angulo3)) * radio3
	$sol/Sprite2D.rotation += 0.2 * delta
